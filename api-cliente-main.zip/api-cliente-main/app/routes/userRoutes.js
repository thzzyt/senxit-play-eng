const express = require('express');
const userController = require('../controllers/userController');
const {authenticate} = require('../controllers/userController');
const router = express.Router();

router.post('/register', userController.register);
router.post('/login', userController.login);

router.use(authenticate);

router.post('/favorite/:userId/', userController.addToFavorites);
router.delete('/favorite/:userId/', userController.removeFromFavorites);
router.get('/:userId', userController.getUserById);
router.get('/', userController.getAllUsers);
router.delete('/:userId', userController.removeUserById);
router.post('/comentarios', userController.adicionarComentario);
router.put('/edit/:userId', userController.editUser);

module.exports = router;
