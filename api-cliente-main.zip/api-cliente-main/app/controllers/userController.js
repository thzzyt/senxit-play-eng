const jwt = require('jsonwebtoken');
const { User, Favoritos, Comentario } = require('../models/User');

const register = async (req, res) => {
  try {
    const { email, password, username, serial, type, anos, dias, meses,  teste, status, } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'Email já está em uso.' });
    }

    const currentDate = new Date();
    const formattedDate = currentDate.toISOString().split('T')[0];

    const options = { timeZone: 'America/Sao_Paulo', hour12: false };
    const formattedTime = currentDate.toLocaleTimeString('en-US', options);

    const newUser = await User.create({
      email,
      password,
      data_c: formattedDate,
      data_l: formattedDate,
      hora_l: formattedTime,
      username,
      serial,
      type,
      anos,
      dias,
      meses,
      teste,
      status,
    });

    const token = jwt.sign({ id: newUser._id, email: newUser.email }, '1234567');

    res.status(201).json({
      message: 'Usuário criado com sucesso.',
      user: {
        email: newUser.email,
        data_c: newUser.data_c,
        data_l: newUser.data_l,
        hora_l: newUser.hora_l,
        username: newUser.username,
        serial: newUser.serial
      },
      token
    });
  } catch (error) {

    console.error(error);
    res.status(500).json({ message: 'Erro no registro de usuário.' });
  }
};

const login = async (req, res) => {
  try {
    const { email, password, serial } = req.body;

    const user = await User.findOne({ email });

    if (!user || user.password !== password) {
      return res.status(401).json({ message: 'Email ou senha incorretos.' });
    }

    const currentDate = new Date();
    const formattedDate = currentDate.toISOString().split('T')[0]; // Extract date

    const options = { timeZone: 'America/Sao_Paulo', hour12: false };
    const formattedTime = currentDate.toLocaleTimeString('en-US', options);

    const updatedUser = await User.findOneAndUpdate(
      { email },
      { $set: { data_l: formattedDate, hora_l: formattedTime, serial } },
      { new: true }
    );

    if (!updatedUser) {
      return res.status(500).json({ message: 'Erro ao atualizar informações do usuário.' });
    }

    const token = jwt.sign({ id: updatedUser._id, email: updatedUser.email }, '1234567');

    res.status(200).json({
      message: 'Usuário logado com sucesso.',
      token,
      userId: updatedUser._id,
      data_l: updatedUser.data_l,
      hora_l: updatedUser.hora_l,
      username: updatedUser.username,
      serial: updatedUser.serial,
      loginDate: formattedDate,
      loginTime: formattedTime
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro no processo de login.' });
  }
};

const authenticate = (req, res, next) => {
  const token = req.header('x-auth-token');

  if (!token) {
    return res.status(401).json({ message: 'Token de autenticação não fornecido.' });
  }

  try {
    const decoded = jwt.verify(token, '1234567');
    req.user = decoded;
    next();
  } catch (error) {
    console.error(error);
    res.status(401).json({ message: 'Token de autenticação inválido.' });
  }
};

const addToFavorites = async (req, res) => {
  try {
    const { type, status, validade, favoritos, anos, dias, hora, meses, serial, teste, uid } = req.body;
    const userId = req.params.userId;

    if (!Array.isArray(favoritos)) {
      return res.status(400).json({ message: 'A chave "favoritos" deve ser um array de objetos.' });
    }

    const user = await User.findById(userId);

    if (!user) {

      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    user.type = type || 'Padrão';
    user.status = status || 'Padrão';
    user.validade = validade || 'Padrão';
    user.anos = anos || 'Padrão';
    user.dias = dias || 'Padrão';
    user.hora = hora || 'Padrão';
    user.meses = meses || 'Padrão';
    user.serial = serial || 'Padrão';
    user.teste = teste || 'Padrão';
    user.uid = uid || 'Padrão';

    for (const favorito of favoritos) {
      const result = await user.addGame(favorito.name, favorito.url, favorito.imagem);
      if (!result.success) {

        return res.status(400).json({ message: result.message });
      }
    }
    
    res.status(200).json({ message: 'Jogos adicionados aos favoritos com sucesso.', user });
    
  } catch (error) {
    res.status(500).json({ message: 'Erro ao adicionar os jogos aos favoritos.' });
  }
};


const removeFromFavorites = async (req, res) => {
  try {
    console.log('Início da rota removeFromFavorites');

    const token = req.header('x-auth-token');
    console.log('Token recebido:', token);

    if (!token) {
      console.log('Usuário não autenticado.');
      return res.status(401).json({ message: 'Usuário não autenticado.' });
    }

    const userId = req.user.id;
    console.log('UserID:', userId);

    const { animeId } = req.body;
    console.log('Anime para remover:', animeId);

    const user = await User.findById(userId);

    if (!user) {
      console.log('Usuário não encontrado.');
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    const isAnimeInFavorites = user.favoritos.includes(animeId);
    if (!isAnimeInFavorites) {
      console.log('Anime não encontrado nos favoritos do usuário.');
      return res.status(404).json({ message: 'Anime não encontrado nos favoritos do usuário.' });
    }

    await Favoritos.findOneAndDelete({ _id: animeId, addedBy: userId });

    user.favoritos.pull(animeId);
    await user.save();

    console.log('Anime removido dos favoritos com sucesso.');

    res.status(200).json({ message: 'Anime removido dos favoritos com sucesso.' });
  } catch (error) {
    console.error('Erro ao remover o anime dos favoritos:', error);
    res.status(500).json({ message: 'Erro ao remover o anime dos favoritos.' });
  }
};

const getUserById = async (req, res) => {
  try {
    const userId = req.params.userId;

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    const currentDate = new Date();
    const creationDate = new Date(user.data_c);

    const diferencaTempo = currentDate - creationDate;

    const diferencaDias = Math.floor(diferencaTempo / (1000 * 60 * 60 * 24));

    if (diferencaDias > 30 && user.status !== 'expirado') {
      user.status = 'expirado';
      await user.save();
    }

    const favoritos = await Favoritos.find({ addedBy: user._id });

    const usuarioFormatado = {
      id: user._id,
      username: user.username,
      email: user.email,
      password: user.password,
      data_c: user.data_c,
      type: user.type,
      status: user.status,
      anos: user.anos,
      dias: user.dias,
      hora: user.hora,
      meses: user.meses,
      serial: user.serial,
      teste: user.teste,
      validade: user.validade,
      data_l: user.data_l,
      hora_l: user.hora_l,
      favoritos: favoritos.map(anime => ({
        id: anime._id,
        name: anime.name,
        url: anime.url,
        imagem: anime.imagem
      })),
    };

    return res.status(200).json({ user: usuarioFormatado });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao obter os dados do usuário.' });
  }
};

const removeUserById = async (req, res) => {
  try {
    const userId = req.params.userId;

    const user = await User.findOne({ _id: userId });

    if (!user) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    await User.findOneAndDelete({ _id: userId });

    res.status(200).json({ message: 'Usuário removido com sucesso.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao remover o usuário.' });
  }
};

const getAllUsers = async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json({ users });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao obter a lista de usuários.' });
  }
};

const adicionarComentario = async (req, res) => {
  try {
    const { name, email, message, animeUrl, userId } = req.body;

    const usuario = await User.findById(userId);

    if (!usuario) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    const novoComentario = await Comentario.create({
      name,
      email,
      message,
      animeUrl,
      usuario: userId,
    });

    usuario.comentarios.push(novoComentario);
    await usuario.save();

    res.status(201).json({ message: 'Comentário adicionado com sucesso.', comentario: novoComentario });
  } catch (error) {
    console.error('Erro ao adicionar comentário:', error);
    res.status(500).json({ message: 'Erro ao adicionar comentário.' });
  }
};

const editUser = async (req, res) => {
  try {
    const userId = req.params.userId;
    const updatedUserData = req.body;

    const updatedUser = await User.findByIdAndUpdate(userId, updatedUserData, { new: true });

    if (!updatedUser) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    res.status(200).json({ message: 'Dados do usuário atualizados com sucesso.', user: updatedUser });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao atualizar dados do usuário.' });
  }
}
module.exports = { register, login, authenticate, addToFavorites, removeFromFavorites, getUserById, removeUserById, getAllUsers, adicionarComentario, editUser };
