const mongoose = require('mongoose');

const { Schema } = mongoose;


mongoose.connect('mongodb+srv://visionanimes:visionanimes@cluster0.y8zigbu.mongodb.net/', { useNewUrlParser: true, useUnifiedTopology: true });


const userSchema = new Schema({
  email: { type: String, required: true },
  password: { type: String, required: true },
  username: { type: String, default: 'Padrão' },
  data_c: { type: String, default: 'Padrão' },
  data_l: { type: String, default: 'Padrão' },
  hora_l: { type: String, default: 'Padrão' },
  type: { type: String, default: 'Padrão' },
  anos: { type: String, default: 'Padrão' },
  dias: { type: String, default: 'Padrão' },
  meses: { type: String, default: 'Padrão' },
  serial: { type: String, default: 'Padrão' },
  teste: { type: String, default: 'Padrão' },
  status: { type: String, default: 'Padrão' },
  validade: { type: String },
  favoritos: [{ type: Schema.Types.ObjectId, ref: 'Anime' }],
  comentarios: [{ type: Schema.Types.ObjectId, ref: 'Comentario' }],
});

const favoritosSchema = new Schema({
  name: { type: String, required: true },
  url: { type: String, required: true },
  imagem: { type: String, required: true },
  addedBy: { type: Schema.Types.ObjectId, ref: 'User' },
});


const Favoritos = mongoose.model('Anime', favoritosSchema);

userSchema.methods.addGame = async function (gameName, gameUrl, gameImagem) {

  const existingGame = await Favoritos.findOne({
    name: gameName,
    addedBy: this._id,
  });


  if (!existingGame) {
    const newGame = await Favoritos.create({
      name: gameName,
      url: gameUrl,
      imagem: gameImagem,
      addedBy: this._id,
    });
  
    this.favoritos.push(newGame);
    await this.save();
    return { success: true, message: `Jogo ${gameName} adicionado aos favoritos.` };
  } else {
    return { success: false, message: `O jogo ${gameName} já está na lista de favoritos.` };
  }
  
};

const User = mongoose.model('User', userSchema);

const comentarioSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  message: { type: String, required: true },
  animeUrl: { type: String, required: true },
  usuario: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // Referência ao usuário associado
});

const Comentario = mongoose.model('Comentario', comentarioSchema);

module.exports = {
  User,
  Favoritos,
  Comentario,
};
